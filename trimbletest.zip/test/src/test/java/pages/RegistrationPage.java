package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage {
	
	WebDriver driver;

        public RegistrationPage(WebDriver driver){ 
                this.driver=driver; 
        }
	
        //Using FindBy for locating elements
    
	@FindBy(how=How.XPATH, using="//input[@id='id_gender1']") WebElement TitleRadio;
	@FindBy(how=How.XPATH, using="//button[@id='SubmitLogin']") WebElement SignInButton;
	@FindBy(how=How.XPATH, using="//input[@id='email_create']") WebElement CreateEmailInput;
	@FindBy(how=How.XPATH, using="//button[@id='SubmitCreate']") WebElement CreatAccButton;
	@FindBy(how=How.XPATH, using="//input[@id='customer_firstname']") WebElement FirstNameField;
	@FindBy(how=How.XPATH, using="//input[@id='customer_lastname']") WebElement LastNameField;
	@FindBy(how=How.XPATH, using="//input[@id='passwd']") WebElement PasswordField;
	@FindBy(how=How.XPATH, using="//input[@id='firstname']") WebElement AddFirstNameField;
	@FindBy(how=How.XPATH, using="//input[@id='lastname']") WebElement AddLastNameField;
	@FindBy(how=How.XPATH, using="//input[@id='address1']") WebElement AddressField;
	@FindBy(how=How.XPATH, using="//input[@id='city']") WebElement CityField;
	@FindBy(how=How.XPATH, using="//select[@id='id_state']") WebElement StateDropdown;
	@FindBy(how=How.XPATH, using="//input[@id='postcode']") WebElement ZipCodeField;
	@FindBy(how=How.XPATH, using="//div[@id='uniform-id_country']") WebElement CountryField;
	@FindBy(how=How.XPATH, using="//input[@id='phone_mobile']") WebElement MobilePhoneField;
	@FindBy(how=How.XPATH, using="//input[@id='alias']") WebElement AliasAddress;
	@FindBy(how=How.XPATH, using="//button[@id='submitAccount']") WebElement RegisterButton;
	@FindBy(how=How.XPATH, using="//p[@class='info-account']") WebElement RegisterMessage;
	
	
	public String Registration(){
		
		SignInButton.click();
		CreateEmailInput.sendKeys("msmathi0207@gmail.com");
		CreatAccButton.click();
		FirstNameField.sendKeys("Mathi");
		LastNameField.sendKeys("azhagan");
		AddressField.sendKeys("chennaichennai");
		CityField.sendKeys("Chennai");
		Select state = new Select(StateDropdown);
		state.selectByVisibleText("Alabama");
		ZipCodeField.sendKeys("00000");
		MobilePhoneField.sendKeys("9787792918");
		RegisterButton.click();
		String RegisterSuccessMessage = RegisterMessage.getText();
		return RegisterSuccessMessage;	
				
	}


}
package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomePage {
	
	WebDriver driver;

        public HomePage(WebDriver driver){ 
                this.driver=driver; 
        }
	
        //Using FindBy for locating elements
	@FindBy(how=How.XPATH, using="//a[@title='Log in to your customer account']") WebElement SignInLink;
	@FindBy(how=How.XPATH, using="//input[@id='email']") WebElement EmailLoginInput;
	@FindBy(how=How.XPATH, using="//input[@id='passwd']") WebElement PasswordInput;
	@FindBy(how=How.XPATH, using="//button[@id='SubmitLogin']") WebElement SignInButton;
	@FindBy(how=How.XPATH, using="//input[@id='email_create']") WebElement CreateEmailInput;
	@FindBy(how=How.XPATH, using="//button[@id='SubmitCreate']") WebElement CreatAccButton;
	@FindBy(how=How.XPATH, using="//h1[text()='My account']") WebElement AccountInfo;
	@FindBy(how=How.XPATH, using="//a[@title='Log me out']") WebElement SignOutLink;
	
       

        // This method to click on SignIn
	public String SignIn(){
		SignInLink.click();
		EmailLoginInput.sendKeys("msmathi0207@gmail.com");
		PasswordInput.sendKeys("tested");
		String AccountInformation = AccountInfo.getText();
		return AccountInformation;
		
	}
	// This method to click on SignOut
	public void SignOut(){
		SignOutLink.click();
	}


}
package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CheckoutPage {
	
	WebDriver driver;

        public CheckoutPage(WebDriver driver){ 
                this.driver=driver; 
        }
	
        //Using FindBy for locating elements
	@FindBy(how=How.XPATH, using="(//a[@title='T-shirts'])[2]") WebElement TshirtLink;
	@FindBy(how=How.XPATH, using="(//a[@title='Faded Short Sleeve T-shirts'])[2]") WebElement FadedTshirtLink;
	@FindBy(how=How.XPATH, using="//button[@name='Submit']/span") WebElement AddToCartButton;
	@FindBy(how=How.XPATH, using="//span[contains(text(),'Proceed to checkout')]") WebElement ProCkeckOutLink;
	@FindBy(how=How.XPATH, using="(//span[contains(text(),'Proceed to checkout')])[2]") WebElement SumCheckOut;
	@FindBy(how=How.XPATH, using="//input[@id='cgv']") WebElement TermCheck;
	@FindBy(how=How.XPATH, using="//a[@title='Pay by bank wire']") WebElement PayBankWireLink;
	@FindBy(how=How.XPATH, using="//span[text()='I confirm my order']") WebElement ConformOrder;
	@FindBy(how=How.XPATH, using="//strong[text()='Your order on My Store is complete.']") WebElement CompleteText;
	@FindBy(how=How.XPATH, using="//input[@id='postcode']") WebElement ZipCodeField;
	@FindBy(how=How.XPATH, using="//div[@id='uniform-id_country']") WebElement CountryField;
	@FindBy(how=How.XPATH, using="//input[@id='phone_mobile']") WebElement MobilePhoneField;
	@FindBy(how=How.XPATH, using="//input[@id='alias']") WebElement AliasAddress;
	@FindBy(how=How.XPATH, using="//button[@id='submitAccount']") WebElement RegisterButton;
	@FindBy(how=How.XPATH, using="//p[@class='info-account']") WebElement RegisterMessage;
	
		
        
	public String Checkout(){
		TshirtLink.click();
		FadedTshirtLink.click();
		AddToCartButton.click();
		ProCkeckOutLink.click();
		SumCheckOut.click();
		SumCheckOut.click();
		TermCheck.click();
		SumCheckOut.click();
		PayBankWireLink.click();
		ConformOrder.click();
		String conformmessage = CompleteText.getText();
		return conformmessage;
	}
	

}
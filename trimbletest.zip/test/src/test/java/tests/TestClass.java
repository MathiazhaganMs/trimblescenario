package tests;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.CheckoutPage;
import pages.HomePage;
import pages.RegistrationPage;

public class TestClass extends TestBase{
	
	@Test
	public void init() throws Exception{

			
			HomePage homepage = PageFactory.initElements(driver, HomePage.class);
			String info = homepage.SignIn();
			Assert.assertEquals(info, "My account");
			
		}
	@Test
	public void SignOut() throws Exception{

		
			HomePage homepage = PageFactory.initElements(driver, HomePage.class);
			homepage.SignOut();
			
			
		}
	@Test
	public void Registration() throws Exception{

			//driver.get("https://www.facebook.com");
			RegistrationPage regpage = PageFactory.initElements(driver, RegistrationPage.class);
			String Accinfo = regpage.Registration();
			Assert.assertEquals(Accinfo, "My account");
			
		}
	@Test
	public void Checkout() throws Exception{
			
			
			HomePage homepage = PageFactory.initElements(driver, HomePage.class);
			String info = homepage.SignIn();	
			CheckoutPage checkpage = PageFactory.initElements(driver, CheckoutPage.class);
			String checkinfo = checkpage.Checkout();
			Assert.assertEquals(checkinfo, "Order confirmation");
			
		}
	
}